FALLOMOTOR — versión funcional inicial

1. Sube todos los archivos y carpetas al repositorio conservando la estructura.
2. El archivo principal debe llamarse index.html.
3. Activa GitHub Pages desde Settings > Pages.
4. La IA no está conectada: requiere un backend seguro.
5. La base contiene 600 casos estructurados generados desde familias de averías. Debe revisarse y validarse técnicamente antes de presentarla como base profesional verificada.

Páginas legales incluidas en esta versión: Política de privacidad y Política de cookies.
