
let averias=[], selected=new Set();
document.querySelector('.menu-toggle')?.addEventListener('click',()=>document.querySelector('.site-header nav').classList.toggle('open'));
document.querySelectorAll('.symptom').forEach(btn=>btn.addEventListener('click',()=>{btn.classList.toggle('active');const c=btn.dataset.category;btn.classList.contains('active')?selected.add(c):selected.delete(c)}));
fetch('data/averias.json').then(r=>r.json()).then(d=>averias=d).catch(()=>{});
const normalize=s=>(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
document.querySelector('#diagnosisForm')?.addEventListener('submit',e=>{
 e.preventDefault();
 const text=normalize(document.querySelector('#textoSintoma').value);
 const dtc=normalize(document.querySelector('#dtc').value);
 const terms=text.split(/\W+/).filter(x=>x.length>2);
 let matches=averias.map(a=>{
   let score=0;
   if(selected.has(a.categoria)) score+=40;
   const hay=normalize([a.nombre,...a.sintomas,...a.causas,...a.dtc].join(' '));
   terms.forEach(t=>{if(hay.includes(t))score+=8});
   if(dtc && normalize(a.dtc.join(' ')).includes(dtc))score+=55;
   return {...a,score};
 }).filter(a=>a.score>0).sort((a,b)=>b.score-a.score).slice(0,5);
 if(!matches.length) matches=averias.slice(0,3).map(a=>({...a,score:10}));
 const results=document.querySelector('#results');results.classList.remove('hidden');
 results.innerHTML='<h2>Resultado orientativo</h2><p>Estas coincidencias no sustituyen una diagnosis profesional. Confirma siempre con pruebas.</p>'+
 matches.map((a,i)=>`<article><h3>${i+1}. ${a.nombre}</h3><span class="badge">Coincidencia ${Math.min(95,a.score+20)}%</span> <span class="badge">Urgencia ${a.urgencia}</span><p><b>Síntomas:</b> ${a.sintomas.join(', ')}</p><p><b>Posibles causas:</b> ${a.causas.join(', ')}</p><p><b>Comprobaciones:</b> ${a.comprobaciones.join(' ')}</p>${a.dtc.length?`<p><b>DTC relacionados:</b> ${a.dtc.join(', ')}</p>`:''}</article>`).join('');
 const item={date:new Date().toLocaleString('es-ES'),vehicle:{marca:marca.value,modelo:modelo.value,anio:anio.value},categories:[...selected],text:document.querySelector('#textoSintoma').value,results:matches.slice(0,3).map(x=>x.nombre)};
 const history=JSON.parse(localStorage.getItem('fallomotorHistory')||'[]');history.unshift(item);localStorage.setItem('fallomotorHistory',JSON.stringify(history.slice(0,30)));
 results.scrollIntoView({behavior:'smooth'});
});
